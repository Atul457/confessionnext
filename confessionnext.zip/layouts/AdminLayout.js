import React from 'react'

const AdminLayout = () => {
  return (
    <div>AdminLayout</div>
  )
}

export default AdminLayout