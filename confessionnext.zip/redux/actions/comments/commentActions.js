
export const CommentsSend = (data) => {
    return {
        type: 'COMMENTS',
        data
    }
}

