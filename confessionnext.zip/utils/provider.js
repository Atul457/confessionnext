const showAdsAfter_Feed = 7

export {
    showAdsAfter_Feed
}