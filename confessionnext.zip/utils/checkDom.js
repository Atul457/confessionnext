const isWindowPresent = () => typeof window !== "undefined"

export { isWindowPresent }