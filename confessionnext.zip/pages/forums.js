import React from 'react'

const Forums = () => {
    return (
        <div>Forums</div>
    )
}

export default Forums